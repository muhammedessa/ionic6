export const environment = {
  production: true,
  firebaseConfig : {
    apiKey: "AIzaSyDydQSl-9ow2W6Tz4x2uV-bDcLi-xD3DwY",
    authDomain: "fir-crud-915f7.firebaseapp.com",
    databaseURL: "https://fir-crud-915f7.firebaseio.com",
    projectId: "fir-crud-915f7",
    storageBucket: "fir-crud-915f7.appspot.com",
    messagingSenderId: "27759851819",
    appId: "1:27759851819:web:a0467d0879359ccf04ed6e",
    measurementId: "G-L9P38KVZ8D"
  }
};
