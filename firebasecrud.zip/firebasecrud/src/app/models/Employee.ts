export class Employee {
    $key: string;
    name: string;
    email:string;
    mobile:string;
    details:string;
}