import { Component, OnInit } from '@angular/core';
import { ApiService } from '../services/api.service';


import * as moment from 'moment';

@Component({
  selector: 'app-products',
  templateUrl: './products.page.html',
  styleUrls: ['./products.page.scss'],
})
export class ProductsPage implements OnInit {

  productData: any;
   

  constructor( public apiService:ApiService ) { }

  ngOnInit() {
//this.getAllProducts()
  }
  ionViewWillEnter(){
    this.getAllProducts()
  }
  
  getAllProducts(){
this.apiService.getAllProduct().subscribe(res=>{
  //console.log(moment(res.created_at).format("DD/MM/YYYY"))
  this.productData = res
})
  }



  deleteProducts(id){
    this.apiService.deleteProduct(id).subscribe(res=>{
      console.log(res)
      this.getAllProducts()
    })
      }


}
