export class Product {
    id: number;
    name: string;
    price:number;
    created_at: string;
}