import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { throwError ,Observable} from 'rxjs';
import { retry ,catchError} from 'rxjs/operators';
import { Product } from '../model/Product';

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  api_URL = "http://localhost:8000/api/products/"
  
  
  constructor( private http:HttpClient) { }

httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'application/json'
  })
}

handleError(error:HttpErrorResponse){
  if (error.error instanceof ErrorEvent) {
    console.error('Error: ', error.error.message)
  }else{
    console.error("Error From Server: " + error.status +" error was: " + error.error)
  }

  return throwError('Server Error')
}



createProduct(product):  Observable<Product>{
  console.log(JSON.stringify(product))
  return this.http
  .post<Product>(this.api_URL, JSON.stringify(product),this.httpOptions )
  .pipe(retry(2), catchError(this.handleError))
}


getProduct(id):  Observable<Product>{
  return this.http
  .get<Product>(this.api_URL + id )
  .pipe(retry(2), catchError(this.handleError))
}


getAllProduct():  Observable<Product>{
  return this.http
  .get<Product>(this.api_URL   )
  .pipe(retry(2), catchError(this.handleError))
}



updateProduct(id,product):  Observable<Product>{
  return this.http
  .put<Product>(this.api_URL + id, JSON.stringify(product) ,this.httpOptions )
  .pipe(retry(2), catchError(this.handleError))
}



deleteProduct(id):  Observable<Product>{
  return this.http
  .delete<Product>(this.api_URL + id ,this.httpOptions )
  .pipe(retry(2), catchError(this.handleError))
}


}
