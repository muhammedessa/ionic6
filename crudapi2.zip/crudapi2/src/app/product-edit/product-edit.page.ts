import { Component, OnInit } from '@angular/core';
import { ApiService } from '../services/api.service';
import { Router,   ActivatedRoute } from '@angular/router';
import { Product } from '../model/Product';

@Component({
  selector: 'app-product-edit',
  templateUrl: './product-edit.page.html',
  styleUrls: ['./product-edit.page.scss'],
})
export class ProductEditPage implements OnInit {


  data:Product 
  id:string

  constructor(
    public apiService:ApiService,
    public router:Router,
    public activatedRoute: ActivatedRoute
  ) {
    this.data = new Product()
   }

  ngOnInit() {
    this.id = this.activatedRoute.snapshot.paramMap.get('id')
    this.apiService.getProduct(this.id).subscribe(res=>{
      console.log(res)
      this.data = res[0]
    })
  }

  update(){
    this.apiService.updateProduct(this.id,this.data).subscribe(response=>{
  
      this.router.navigate(['products'])
    })
  }


}
