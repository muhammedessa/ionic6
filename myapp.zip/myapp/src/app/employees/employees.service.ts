import { Injectable } from '@angular/core';
import { Employee } from './employee.model';

@Injectable({
  providedIn: 'root'
})
export class EmployeesService {

 private employees:Employee[]= [
    {
        id: '1',
        name: 'Muhammed Essa',
        age: 36,
        avatar: 'https://www.w3schools.com/w3images/avatar2.png',
        adress: ['Iraq' , 'Kirkuk', '42342']
    },
    {
      id: '2',
      name: 'Ahmed Essa',
      age: 22,
      avatar: 'https://cdn.icon-icons.com/icons2/1736/PNG/512/4043260-avatar-male-man-portrait_113269.png',
      adress: ['Iraq' , 'Baghdad', '2311']
  },
  {
    id: '3',
    name: 'Osama Essa',
    age: 37,
    avatar: 'https://www.w3schools.com/howto/img_avatar.png',
    adress: ['Iraq' , 'Mosul', '3234']
},
{
  id: '4',
  name: 'Ali Essa',
  age: 41,
  avatar: 'https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSVqhTJArI2RLSSzlY0X1twqrkjMrScCsRWwQ&usqp=CAU',
  adress: ['Iraq' , 'Wasit', '6465']
},
  ]

  constructor() { }


  getAllEmployees(){
    return [...this.employees]
  }

  getEmployeeInfo(employeeid: string){
    return {

      ...this.employees.find( emp => { 
        return emp.id === employeeid;
      })
    }
  }


  deleteEmployeeInfo(employeeid: string){
   
     this.employees = this.employees.filter( emp => { 
        return emp.id !== employeeid;
      })
  
  }


}
