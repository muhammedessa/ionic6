export interface Employee {
    id: string;
    name: string;
    age: number;
    avatar: string;
    adress:string[];
}