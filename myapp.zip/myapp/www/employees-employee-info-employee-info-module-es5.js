(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["employees-employee-info-employee-info-module"], {
    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/employees/employee-info/employee-info.page.html":
    /*!*******************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/employees/employee-info/employee-info.page.html ***!
      \*******************************************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppEmployeesEmployeeInfoEmployeeInfoPageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar color=\"danger\">\n    <ion-buttons slot=\"start\">\n<ion-back-button defaultHref='/employees'></ion-back-button>\n    </ion-buttons>\n    <ion-title>{{employeeInfoDetails.name}}</ion-title>\n    <ion-buttons slot=\"primary\">\n      <ion-button (click)=\"deleteEmployee()\">\n        <ion-icon name=\"trash\" slot=\"icon-only\"></ion-icon>\n      </ion-button>\n   </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-card>\n    <ion-img [src]=\"employeeInfoDetails.avatar\"> </ion-img>\n    <ion-card-header> \n      <ion-card-subtitle>{{employeeInfoDetails.age}}</ion-card-subtitle>\n      <ion-card-title>{{employeeInfoDetails.name}}</ion-card-title>\n    </ion-card-header>\n  \n    <ion-card-content>\n      {{employeeInfoDetails.adress}}\n    </ion-card-content>\n  </ion-card>\n  \n</ion-content>\n";
      /***/
    },

    /***/
    "./src/app/employees/employee-info/employee-info-routing.module.ts":
    /*!*************************************************************************!*\
      !*** ./src/app/employees/employee-info/employee-info-routing.module.ts ***!
      \*************************************************************************/

    /*! exports provided: EmployeeInfoPageRoutingModule */

    /***/
    function srcAppEmployeesEmployeeInfoEmployeeInfoRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "EmployeeInfoPageRoutingModule", function () {
        return EmployeeInfoPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _employee_info_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./employee-info.page */
      "./src/app/employees/employee-info/employee-info.page.ts");

      var routes = [{
        path: '',
        component: _employee_info_page__WEBPACK_IMPORTED_MODULE_3__["EmployeeInfoPage"]
      }];

      var EmployeeInfoPageRoutingModule = function EmployeeInfoPageRoutingModule() {
        _classCallCheck(this, EmployeeInfoPageRoutingModule);
      };

      EmployeeInfoPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], EmployeeInfoPageRoutingModule);
      /***/
    },

    /***/
    "./src/app/employees/employee-info/employee-info.module.ts":
    /*!*****************************************************************!*\
      !*** ./src/app/employees/employee-info/employee-info.module.ts ***!
      \*****************************************************************/

    /*! exports provided: EmployeeInfoPageModule */

    /***/
    function srcAppEmployeesEmployeeInfoEmployeeInfoModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "EmployeeInfoPageModule", function () {
        return EmployeeInfoPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _employee_info_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./employee-info-routing.module */
      "./src/app/employees/employee-info/employee-info-routing.module.ts");
      /* harmony import */


      var _employee_info_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./employee-info.page */
      "./src/app/employees/employee-info/employee-info.page.ts");

      var EmployeeInfoPageModule = function EmployeeInfoPageModule() {
        _classCallCheck(this, EmployeeInfoPageModule);
      };

      EmployeeInfoPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _employee_info_routing_module__WEBPACK_IMPORTED_MODULE_5__["EmployeeInfoPageRoutingModule"]],
        declarations: [_employee_info_page__WEBPACK_IMPORTED_MODULE_6__["EmployeeInfoPage"]]
      })], EmployeeInfoPageModule);
      /***/
    },

    /***/
    "./src/app/employees/employee-info/employee-info.page.scss":
    /*!*****************************************************************!*\
      !*** ./src/app/employees/employee-info/employee-info.page.scss ***!
      \*****************************************************************/

    /*! exports provided: default */

    /***/
    function srcAppEmployeesEmployeeInfoEmployeeInfoPageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2VtcGxveWVlcy9lbXBsb3llZS1pbmZvL2VtcGxveWVlLWluZm8ucGFnZS5zY3NzIn0= */";
      /***/
    },

    /***/
    "./src/app/employees/employee-info/employee-info.page.ts":
    /*!***************************************************************!*\
      !*** ./src/app/employees/employee-info/employee-info.page.ts ***!
      \***************************************************************/

    /*! exports provided: EmployeeInfoPage */

    /***/
    function srcAppEmployeesEmployeeInfoEmployeeInfoPageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "EmployeeInfoPage", function () {
        return EmployeeInfoPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _employees_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ../employees.service */
      "./src/app/employees/employees.service.ts");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");

      var EmployeeInfoPage = /*#__PURE__*/function () {
        function EmployeeInfoPage(activatedRoute, router, alertCrtl, employeesService) {
          _classCallCheck(this, EmployeeInfoPage);

          this.activatedRoute = activatedRoute;
          this.router = router;
          this.alertCrtl = alertCrtl;
          this.employeesService = employeesService;
        }

        _createClass(EmployeeInfoPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            var _this = this;

            this.activatedRoute.paramMap.subscribe(function (paramMap) {
              if (!paramMap.has('employeeid')) {
                return;
              }

              var employeeid = paramMap.get('employeeid');
              _this.employeeInfoDetails = _this.employeesService.getEmployeeInfo(employeeid);
            });
          }
        }, {
          key: "deleteEmployee",
          value: function deleteEmployee() {
            var _this2 = this;

            this.alertCrtl.create({
              header: 'You want to Delete !',
              message: "You will Delete this employee",
              buttons: [{
                text: "No",
                role: 'cancel'
              }, {
                text: 'Remove',
                handler: function handler() {
                  _this2.employeesService.deleteEmployeeInfo(_this2.employeeInfoDetails.id);

                  _this2.router.navigate(['/employees']);
                }
              }]
            }).then(function (alertV) {
              alertV.present();
            });
          }
        }]);

        return EmployeeInfoPage;
      }();

      EmployeeInfoPage.ctorParameters = function () {
        return [{
          type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]
        }, {
          type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"]
        }, {
          type: _employees_service__WEBPACK_IMPORTED_MODULE_3__["EmployeesService"]
        }];
      };

      EmployeeInfoPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-employee-info',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./employee-info.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/employees/employee-info/employee-info.page.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./employee-info.page.scss */
        "./src/app/employees/employee-info/employee-info.page.scss"))["default"]]
      })], EmployeeInfoPage);
      /***/
    }
  }]);
})();
//# sourceMappingURL=employees-employee-info-employee-info-module-es5.js.map